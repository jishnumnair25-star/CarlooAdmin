<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
</head>
<body>
    <div class="container mt-5">
        <h2>Welcome, <?php echo e(session('username')); ?></h2>

        <p><strong>User ID:</strong> <?php echo e(session('user_id')); ?></p>
        <p><strong>Profile Completed:</strong> <?php echo e(session('profile_completed') ? 'Yes' : 'No'); ?></p>
        <p><strong>Access Token:</strong> <?php echo e(session('access_token')); ?></p> <h2>Welcome, <?php echo e(session('username')); ?></h2>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\Laravel-Fasto-v1.0.1-14-May-2025\package\resources\views/dashboard.blade.php ENDPATH**/ ?>