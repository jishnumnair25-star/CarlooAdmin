<div class="footer">
    <div class="copyright">
         <p>Copyright © Designed &amp; Developed by <a href="http://design-pods.com/" target="_blank">Design-pods</a> 2025</p>
    </div>
</div><?php /**PATH C:\xampp\htdocs\Laravel-Fasto-v1.0.1-14-May-2025\package\resources\views/elements/footer.blade.php ENDPATH**/ ?>