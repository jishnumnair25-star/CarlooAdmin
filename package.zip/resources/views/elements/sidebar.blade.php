


<div class="deznav">
    <div class="deznav-scroll">
        <a class="add-project-sidebar btn btn-primary" href="javascript:void(0)"  data-bs-toggle="modal" data-bs-target="#addProjectSidebar" >+ New Project</a>
        <ul class="metismenu" id="menu">
            <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="false">
                    <i class="flaticon-layout"></i>
                    <span class="nav-text">Dashboard</span>
                </a>
                <ul aria-expanded="false">
                    <li><a href="{{ url('index')}}">Dashboard</a></li>
                </ul>

            </li>

            <li><a href="{{ url('projects')}}" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-contract"></i>
                    <span class="nav-text">Project</span>
                </a>
            </li>

             <li><a href="{{ url('ui-card')}}" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-table"></i>
                    <span class="nav-text">Choose Plan</span>
                </a>
            </li>
            <li>
                <a href="{{ url('table-bootstrap-basic')}}" class="ai-icon" aria-expanded="false">
                     <i class="flaticon-web"></i>
                    <span class="nav-text">Subscriptions</span>
                </a>
            </li>
             <li><a href="{{ url('ui-alert')}}" class="ai-icon" aria-expanded="false">
                      <i class="flaticon-monitor"></i>
                    <span class="nav-text">Supportcenter</span>
                </a>
            </li>

<li><a href="{{ url('table-datatable-basic')}}" class="ai-icon" aria-expanded="false">
                    <i class="flaticon-admin"></i>
                    <span class="nav-text">User  Framework</span>
                </a>
            </li>


        </ul>
        <!-- <div class="copyright">
            <p><strong>Fasto Saas Admin Dashboard</strong> © 2023 All Rights Reserved</p>
            <p class="fs-12">Made with <span class="heart"></span> by DexignZone</p>
        </div> -->
    </div>
</div>
