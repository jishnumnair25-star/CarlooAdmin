@extends('layouts.default')

@section('content')
<div class="container-fluid">
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title">Edit Project</h4>
                </div>
                <div class="card-body">
                    <form id="editProjectForm" method="POST" action="{{ route('projects.update', $project['_id']) }}">
                        @csrf
                        @method('PUT')
                        
                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="project_name" class="form-label">Project Name *</label>
                                    <input type="text" class="form-control" id="project_name" name="project_name" 
                                           value="{{ $project['project_name'] ?? '' }}" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="subscription_id" class="form-label">Subscription ID *</label>
                                    <select class="form-select" id="subscription_id" name="subscription_id" required>
                                        <option value="">Select Subscription</option>
                                        @foreach($subscriptions as $subscription)
                                            <option value="{{ $subscription['_id'] }}" 
                                                    {{ ($project['subscription_id'] ?? '') == $subscription['_id'] ? 'selected' : '' }}>
                                                {{ $subscription['_id'] }} - {{ $subscription['pricing_tier'] ?? 'Unknown' }}
                                            </option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="project_description" class="form-label">Project Description *</label>
                            <textarea class="form-control" id="project_description" name="project_description" rows="3" required>{{ $project['project_description'] ?? '' }}</textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="industry_domain" class="form-label">Industry Domain *</label>
                                    <input type="text" class="form-control" id="industry_domain" name="industry_domain" 
                                           value="{{ $project['industry_domain'] ?? '' }}" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status *</label>
                                    <select class="form-select" id="status" name="status" required>
                                        <option value="">Select Status</option>
                                        <option value="draft" {{ ($project['status'] ?? '') == 'draft' ? 'selected' : '' }}>Draft</option>
                                        <option value="pending" {{ ($project['status'] ?? '') == 'pending' ? 'selected' : '' }}>Pending</option>
                                        <option value="active" {{ ($project['status'] ?? '') == 'active' ? 'selected' : '' }}>Active</option>
                                        <option value="in active" {{ ($project['status'] ?? '') == 'in active' ? 'selected' : '' }}>In Active</option>
                                        <option value="archived" {{ ($project['status'] ?? '') == 'archived' ? 'selected' : '' }}>Archived</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label for="data_storage_location" class="form-label">Data Storage Location *</label>
                            <input type="text" class="form-control" id="data_storage_location" name="data_storage_location" 
                                   value="{{ $project['data_storage_location'] ?? '' }}" required>
                        </div>

                        <div class="text-end mt-4">
                            <a href="{{ route('projects.list') }}" class="btn btn-secondary me-2">Cancel</a>
                            <button type="submit" class="btn btn-primary">Update Project</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Form submission
    document.getElementById('editProjectForm').addEventListener('submit', async function(e) {
        e.preventDefault();

        try {
            const response = await fetch(this.action, {
                method: "POST",
                headers: {
                    "X-CSRF-TOKEN": document.querySelector('input[name="_token"]').value,
                    "Accept": "application/json"
                },
                body: new FormData(this)
            });

            const result = await response.json();

            if (result.success) {
                alert("✅ Project updated successfully!");
                window.location.href = "{{ route('projects.list') }}";
            } else {
                alert("❌ Failed to update project: " + result.message);
            }
        } catch (error) {
            console.error('Error:', error);
            alert("❌ An error occurred while updating the project");
        }
    });
});
</script>
@endpush
@endsection
