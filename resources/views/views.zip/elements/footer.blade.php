<div class="footer">
    <div class="copyright">
         <p>Copyright © Designed &amp; Developed by <a href="http://design-pods.com/" target="_blank">Design-pods</a> 2025</p>
    </div>
</div>